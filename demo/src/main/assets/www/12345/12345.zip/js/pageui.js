// JavaScript Document
function tabselect(btn,num){//改变tab选中状态
	$(btn).closest('ul').find('a').removeClass('select');
	btn.className = "select";
	$('#xz').val(num);
}

(function(a) {
    a.fn.webwidget_rating_simple = function(p) {
        var p = p || {};
        var b = p && p.rating_star_length ? p.rating_star_length: "5";
        var c = p && p.rating_function_name ? p.rating_function_name: "";
        var e = p && p.rating_initial_value ? p.rating_initial_value: "";
        var d = p && p.directory ? p.directory: "img";
		var t = p && p.rating_texts ? p.rating_texts: "未评价";
        var f = "";
        var g = a(this);
        b = parseInt(b);
        init();
        g.next("ul").children("li").hover(function() {
            //$(this).parent().children("li").css('background-image', 'url(' + d + '/nst.gif)');
			$(this).parent().children("li").attr("class","icoStar");
            var a = $(this).parent().children("li").index($(this));
           // $(this).parent().children("li").slice(0, a + 1).css('background-image', 'url(' + d + '/sth.gif)')
		   $(this).parent().children("li").slice(0, a + 1).attr("class","icoStar starSel");
		   $('.rating_resultText').html(t[a])
        },
        function() {});
        g.next("ul").children("li").click(function() {
            var a = $(this).parent().children("li").index($(this));
            f = a + 1;
            g.val(f);
            if (c != "") {
                eval(c + "(" + g.val() + ")")
            }
        });
        g.next("ul").hover(function() {},
        function() {
            if (f == "") {
                //$(this).children("li").css('background-image', 'url(' + d + '/nst.gif)')
				$(this).children("li").attr("class","icoStar");
				$('.rating_resultText').html("未评价")
            } else {
                //$(this).children("li").css('background-image', 'url(' + d + '/nst.gif)');
                //$(this).children("li").slice(0, f).css('background-image', 'url(' + d + '/sth.gif)')
                $(this).children("li").attr("class","icoStar");
                $(this).children("li").slice(0, f).attr("class","icoStar starSel");
				$('.rating_resultText').html(t[f-1])
            }
        });
        function init() {
            $('<div style="clear:both;"></div>').insertAfter(g);
            g.css("float", "left");
            var a = $("<ul>");
            a.attr("class", "webwidget_rating_simple");
            for (var i = 1; i <= b; i++) {
                //a.append('<li style="background-image:url(' + d + '/nst.gif)"><span>' + i + '</span></li>')
				a.append('<li class="icoStar"><span>' + i + '</span></li>')
            }
            a.insertAfter(g);
            if (e != "") {
                f = e;
                g.val(e);
                //g.next("ul").children("li").slice(0, f).css('background-image', 'url(' + d + '/sth.gif)')
				g.next("ul").children("li").slice(0, f).attr("class","icoStar starSel");
				$('.rating_resultText').html(t[f-1])
            }else{
				$('.rating_resultText').html("未评价")
			}
        }
    }
})(jQuery);